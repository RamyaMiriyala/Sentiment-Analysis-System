CREATE DATABASE IF NOT EXISTS sentiscope CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sentiscope;

CREATE TABLE IF NOT EXISTS posts (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    keyword      VARCHAR(255) NOT NULL,
    text         TEXT NOT NULL,
    clean_text   TEXT,
    sentiment    ENUM('Positive','Negative','Neutral') NOT NULL,
    polarity     FLOAT DEFAULT 0.0,
    subjectivity FLOAT DEFAULT 0.0,
    emotion      VARCHAR(50) DEFAULT 'neutral',
    toxicity     FLOAT DEFAULT 0.0,
    sarcastic    TINYINT DEFAULT 0,
    nlp_engine   VARCHAR(50) DEFAULT 'php_lexicon',
    source       VARCHAR(100) DEFAULT 'sample',
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_keyword(keyword),
    INDEX idx_sentiment(sentiment),
    INDEX idx_created(created_at),
    INDEX idx_emotion(emotion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    keyword      VARCHAR(255) NOT NULL,
    total_posts  INT DEFAULT 0,
    positive     INT DEFAULT 0,
    negative     INT DEFAULT 0,
    neutral      INT DEFAULT 0,
    avg_polarity FLOAT DEFAULT 0.0,
    sources_used VARCHAR(500) DEFAULT '',
    nlp_engine   VARCHAR(100) DEFAULT 'php_lexicon',
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_keyword(keyword),
    INDEX idx_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cache (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    cache_key  VARCHAR(255) NOT NULL UNIQUE,
    data       LONGTEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_key(cache_key),
    INDEX idx_expires(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pinned (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    keyword    VARCHAR(255) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
