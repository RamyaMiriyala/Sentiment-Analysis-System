<?php
require_once '../includes/db.php';
$db   = getDB();
$kw   = trim($_GET['keyword']??'');
$fmt  = $_GET['format']??'csv';

$sql  = $kw ? "SELECT * FROM posts WHERE keyword LIKE ? ORDER BY created_at DESC" : "SELECT * FROM posts ORDER BY created_at DESC";
$stmt = $db->prepare($sql);
if ($kw){$like='%'.$kw.'%';$stmt->bind_param('s',$like);}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$fn = 'sentiscope_'.($kw?preg_replace('/\W/','_',$kw):'all').'_'.date('Ymd_His');

if ($fmt==='csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="'.$fn.'.csv"');
    $out = fopen('php://output','w');
    fputcsv($out,array('ID','Keyword','Text','Sentiment','Polarity','Subjectivity','Emotion','Toxicity','Source','Date'));
    foreach ($rows as $r) fputcsv($out,array($r['id'],$r['keyword'],$r['text'],$r['sentiment'],$r['polarity'],$r['subjectivity'],$r['emotion']??'',$r['toxicity']??0,$r['source'],$r['created_at']));
    fclose($out);
} else {
    // Simple HTML report for PDF printing
    header('Content-Type: text/html');
    $total = count($rows);
    $pos   = count(array_filter($rows,function($r){return $r['sentiment']==='Positive';}));
    $neg   = count(array_filter($rows,function($r){return $r['sentiment']==='Negative';}));
    $neu   = count(array_filter($rows,function($r){return $r['sentiment']==='Neutral';}));
    $avgP  = $total>0?round(array_sum(array_column($rows,'polarity'))/$total,4):0;
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>SentiScope Report</title><style>
    body{font-family:Arial,sans-serif;padding:30px;color:#222}h1{color:#00cba8}
    .stat{display:inline-block;margin:10px;padding:15px 25px;background:#f5f5f5;border-radius:8px;text-align:center}
    .stat b{display:block;font-size:2em;color:#00cba8}.pos{color:#22c55e}.neg{color:#ef4444}.neu{color:#f59e0b}
    table{width:100%;border-collapse:collapse;margin-top:20px;font-size:13px}
    th{background:#00cba8;color:#fff;padding:8px}td{padding:7px;border-bottom:1px solid #eee}
    @media print{button{display:none}}
    </style></head><body>
    <button onclick="window.print()" style="background:#00cba8;color:#fff;border:none;padding:10px 20px;border-radius:6px;cursor:pointer;margin-bottom:20px">Print / Save as PDF</button>
    <h1>SentiScope Analysis Report</h1>
    <p>Keyword: <strong>'.htmlspecialchars($kw?$kw:'All').'</strong> | Generated: '.date('Y-m-d H:i:s').'</p>
    <div><span class="stat"><b>'.$total.'</b>Total</span><span class="stat"><b class="pos">'.$pos.'</b>Positive</span><span class="stat"><b class="neg">'.$neg.'</b>Negative</span><span class="stat"><b class="neu">'.$neu.'</b>Neutral</span><span class="stat"><b>'.($avgP>=0?'+':'').$avgP.'</b>Avg Polarity</span></div>
    <table><thead><tr><th>Text</th><th>Sentiment</th><th>Polarity</th><th>Emotion</th><th>Source</th><th>Date</th></tr></thead><tbody>';
    foreach (array_slice($rows,0,100) as $r) {
        $sc=$r['sentiment']==='Positive'?'pos':($r['sentiment']==='Negative'?'neg':'neu');
        echo '<tr><td>'.htmlspecialchars(substr($r['text'],0,120)).'</td><td class="'.$sc.'"><b>'.$r['sentiment'].'</b></td><td>'.($r['polarity']>=0?'+':'').$r['polarity'].'</td><td>'.($r['emotion']??'').'</td><td>'.$r['source'].'</td><td>'.substr($r['created_at'],0,10).'</td></tr>';
    }
    echo '</tbody></table></body></html>';
}
