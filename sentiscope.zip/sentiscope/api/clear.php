<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(200);exit;}
require_once '../includes/db.php';
$db  = getDB(); $kw = trim($_GET['keyword']??'');
if ($kw){
    $s=$db->prepare('DELETE FROM posts WHERE keyword=?');$s->bind_param('s',$kw);$s->execute();$d=$s->affected_rows;$s->close();
    $s=$db->prepare('DELETE FROM sessions WHERE keyword=?');$s->bind_param('s',$kw);$s->execute();$s->close();
}else{$db->query('DELETE FROM posts');$d=$db->affected_rows;$db->query('DELETE FROM sessions');}
$db->query('DELETE FROM cache WHERE expires_at < NOW()');
echo json_encode(array('deleted'=>$d));
