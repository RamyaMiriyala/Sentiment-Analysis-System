<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once '../includes/db.php';
$db    = getDB();
$limit = max(1,min(100,(int)($_GET['limit']??20)));
$rows  = $db->query("SELECT * FROM sessions ORDER BY created_at DESC LIMIT {$limit}")->fetch_all(MYSQLI_ASSOC);
echo json_encode($rows);
