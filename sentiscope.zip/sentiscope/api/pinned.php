<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(200);exit;}
require_once '../includes/db.php';
$db = getDB();

if ($_SERVER['REQUEST_METHOD']==='GET') {
    $rows = $db->query('SELECT * FROM pinned ORDER BY created_at DESC')->fetch_all(MYSQLI_ASSOC);
    echo json_encode($rows);
} elseif ($_SERVER['REQUEST_METHOD']==='POST') {
    $input = json_decode(file_get_contents('php://input'),true);
    $kw    = trim(preg_replace('/[^\w\s\-]/u','',$input['keyword']??''));
    if (!$kw){echo json_encode(array('error'=>'Keyword required'));exit;}
    $stmt = $db->prepare('INSERT IGNORE INTO pinned (keyword) VALUES (?)');
    $stmt->bind_param('s',$kw); $stmt->execute(); $stmt->close();
    echo json_encode(array('success'=>true,'keyword'=>$kw));
} elseif ($_SERVER['REQUEST_METHOD']==='DELETE') {
    $kw   = trim($_GET['keyword']??'');
    $stmt = $db->prepare('DELETE FROM pinned WHERE keyword=?');
    $stmt->bind_param('s',$kw); $stmt->execute(); $stmt->close();
    echo json_encode(array('success'=>true));
}
