<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(200);exit;}

require_once '../includes/db.php';
require_once '../includes/nlp.php';
require_once '../includes/datasource.php';

$input = json_decode(file_get_contents('php://input'), true);
$kw1   = isset($input['keyword1']) ? trim(preg_replace('/[^\w\s\-]/u','',$input['keyword1'])) : '';
$kw2   = isset($input['keyword2']) ? trim(preg_replace('/[^\w\s\-]/u','',$input['keyword2'])) : '';
$count = isset($input['count'])    ? max(10,min(50,(int)$input['count'])) : 30;

if (!$kw1||!$kw2){http_response_code(400);echo json_encode(array('error'=>'Both keywords required'));exit;}

function analyzeKeyword($kw, $count) {
    $cacheKey = 'compare_'.md5($kw.$count);
    $cached   = getCache($cacheKey);
    if ($cached) return $cached;

    $posts = fetchRealData($kw, $count, array());
    $pos=0;$neg=0;$neu=0;$totalPol=0.0;$emotions=array('joy'=>0,'anger'=>0,'sadness'=>0,'fear'=>0,'surprise'=>0,'disgust'=>0,'neutral'=>0);

    foreach ($posts as $p) {
        $text = isset($p['text'])?substr(trim($p['text']),0,800):'';
        if (strlen($text)<5) continue;
        $nlp = nlp_analyze($text);
        if ($nlp['sentiment']==='Positive') $pos++;
        elseif ($nlp['sentiment']==='Negative') $neg++;
        else $neu++;
        $totalPol += $nlp['polarity'];
        $emo = $nlp['emotion'];
        if (isset($emotions[$emo])) $emotions[$emo]++;
    }
    $n = count($posts);
    $result = array('keyword'=>$kw,'total'=>$n,'positive'=>$pos,'negative'=>$neg,'neutral'=>$neu,'avg_polarity'=>$n>0?round($totalPol/$n,4):0.0,'emotions'=>$emotions);
    setCache($cacheKey,$result,3600);
    return $result;
}

$r1 = analyzeKeyword($kw1,$count);
$r2 = analyzeKeyword($kw2,$count);

$winner = '';
if ($r1['avg_polarity'] > $r2['avg_polarity']) $winner = $kw1;
elseif ($r2['avg_polarity'] > $r1['avg_polarity']) $winner = $kw2;
else $winner = 'Tie';

echo json_encode(array('keyword1'=>$r1,'keyword2'=>$r2,'winner'=>$winner));
