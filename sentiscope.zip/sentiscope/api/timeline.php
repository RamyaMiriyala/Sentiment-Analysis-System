<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once '../includes/db.php';
$db  = getDB();
$kw  = trim($_GET['keyword'] ?? '');
if (!$kw){echo json_encode(array());exit;}
$stmt = $db->prepare("SELECT DATE(created_at) d, AVG(polarity) avg_pol, COUNT(*) total, SUM(sentiment='Positive') pos, SUM(sentiment='Negative') neg, SUM(sentiment='Neutral') neu FROM posts WHERE keyword LIKE ? AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY d ASC");
$like = '%'.$kw.'%';
$stmt->bind_param('s',$like);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
echo json_encode($rows);
