<?php
ini_set('display_errors', 0);
error_reporting(0);

set_exception_handler(function($e) {
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array('error' => 'Exception: ' . $e->getMessage()));
    exit;
});

register_shutdown_function(function() {
    $err = error_get_last();
    if ($err && in_array($err['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR))) {
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('error' => 'Fatal: ' . $err['message']));
    }
});

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(array('error'=>'Method not allowed')); exit; }

require_once '../includes/db.php';
require_once '../includes/nlp.php';
require_once '../includes/datasource.php';

$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
if (!rateLimit($ip, 15, 60)) {
    http_response_code(429);
    echo json_encode(array('error' => 'Rate limit exceeded. Please wait.'));
    exit;
}

$raw     = file_get_contents('php://input');
$input   = json_decode($raw, true);
$keyword = isset($input['keyword']) ? trim(preg_replace('/[^\w\s\-]/u', '', $input['keyword'])) : '';
$keyword = substr($keyword, 0, 100);
$count   = isset($input['count'])   ? max(10, min(100, (int)$input['count'])) : 50;
$sources = isset($input['sources']) && is_array($input['sources']) ? $input['sources'] : array();

if ($keyword === '') { http_response_code(400); echo json_encode(array('error' => 'Keyword is required')); exit; }

// Cache check
$cacheKey = 'v4_' . md5($keyword . implode(',', $sources) . $count);
$cached   = getCache($cacheKey);
if ($cached) { $cached['from_cache'] = true; echo json_encode($cached); exit; }

// Fetch posts
try { $rawPosts = fetchRealData($keyword, $count, $sources); }
catch (Exception $e) { $rawPosts = array(); }
if (empty($rawPosts)) $rawPosts = generateSampleData($keyword, $count);

// Initialize
$results       = array();
$pos = $neg = $neu = 0;
$totalPol      = 0.0;
$emotions      = array('joy'=>0,'anger'=>0,'sadness'=>0,'fear'=>0,'surprise'=>0,'disgust'=>0,'neutral'=>0);
$keyphraseFreq = array();
$sourcesUsed   = array();
$engineUsed    = 'php_lexicon';

$db = getDB();

// Auto-add columns if missing
try {
    $cols = array();
    $r = $db->query("SHOW COLUMNS FROM posts");
    if ($r) while ($row = $r->fetch_assoc()) $cols[] = $row['Field'];
    if (!in_array('emotion',    $cols)) $db->query("ALTER TABLE posts ADD COLUMN emotion VARCHAR(50) DEFAULT 'neutral'");
    if (!in_array('toxicity',   $cols)) $db->query("ALTER TABLE posts ADD COLUMN toxicity FLOAT DEFAULT 0.0");
    if (!in_array('sarcastic',  $cols)) $db->query("ALTER TABLE posts ADD COLUMN sarcastic TINYINT DEFAULT 0");
    if (!in_array('nlp_engine', $cols)) $db->query("ALTER TABLE posts ADD COLUMN nlp_engine VARCHAR(50) DEFAULT 'php_lexicon'");

    $scols = array();
    $sr = $db->query("SHOW COLUMNS FROM sessions");
    if ($sr) while ($row = $sr->fetch_assoc()) $scols[] = $row['Field'];
    if (!in_array('sources_used', $scols)) $db->query("ALTER TABLE sessions ADD COLUMN sources_used VARCHAR(500) DEFAULT ''");
    if (!in_array('nlp_engine',   $scols)) $db->query("ALTER TABLE sessions ADD COLUMN nlp_engine VARCHAR(100) DEFAULT 'php_lexicon'");
} catch (Exception $e) {}

// Process posts
foreach ($rawPosts as $p) {
    try {
        $text      = isset($p['text'])      ? substr(trim((string)$p['text']), 0, 800) : '';
        $source    = isset($p['source'])    ? (string)$p['source'] : 'sample';
        $timestamp = isset($p['timestamp']) ? (string)$p['timestamp'] : date('Y-m-d H:i:s');
        if (strlen($text) < 5) continue;

        $nlp      = nlp_analyze($text);
        $label    = (string)$nlp['sentiment'];
        $polarity = (float)$nlp['polarity'];
        $subj     = (float)$nlp['subjectivity'];
        $clean    = (string)$nlp['clean_text'];
        $emotion  = (string)$nlp['emotion'];
        $toxicity = (float)$nlp['toxicity'];
        $sarcastic= isset($nlp['sarcastic']) && $nlp['sarcastic'] ? 1 : 0;
        $engine   = isset($nlp['engine']) ? (string)$nlp['engine'] : 'php_lexicon';
        $kps      = isset($nlp['keyphrases']) ? $nlp['keyphrases'] : array();

        if ($label === 'Positive') $pos++;
        elseif ($label === 'Negative') $neg++;
        else $neu++;
        $totalPol += $polarity;

        if (isset($emotions[$emotion])) $emotions[$emotion]++;
        else $emotions['neutral']++;

        foreach ($kps as $kp) {
            $keyphraseFreq[$kp] = isset($keyphraseFreq[$kp]) ? $keyphraseFreq[$kp]+1 : 1;
        }

        if ($engine !== 'php_lexicon') $engineUsed = $engine;

        try {
            $kwe = $db->real_escape_string($keyword);
            $txe = $db->real_escape_string($text);
            $cle = $db->real_escape_string($clean);
            $lbe = $db->real_escape_string($label);
            $eme = $db->real_escape_string($emotion);
            $sre = $db->real_escape_string($source);
            $tse = $db->real_escape_string($timestamp);
            $ene = $db->real_escape_string($engine);
            $db->query("INSERT INTO posts (keyword,text,clean_text,sentiment,polarity,subjectivity,emotion,toxicity,sarcastic,nlp_engine,source,created_at) VALUES ('{$kwe}','{$txe}','{$cle}','{$lbe}',{$polarity},{$subj},'{$eme}',{$toxicity},{$sarcastic},'{$ene}','{$sre}','{$tse}')");
        } catch (Exception $e) {}

        if (!in_array($source, $sourcesUsed)) $sourcesUsed[] = $source;

        $scores = isset($nlp['scores']) ? $nlp['scores'] : array();

        $results[] = array(
            'text'         => $text,
            'sentiment'    => $label,
            'polarity'     => $polarity,
            'subjectivity' => $subj,
            'emotion'      => $emotion,
            'toxicity'     => $toxicity,
            'sarcastic'    => (bool)$sarcastic,
            'source'       => $source,
            'timestamp'    => $timestamp,
            'engine'       => $engine,
            'scores'       => $scores
        );
    } catch (Exception $e) { continue; }
}

// Fallback if empty
if (empty($results)) {
    $samples = generateSampleData($keyword, $count);
    foreach ($samples as $p) {
        try {
            $text   = substr(trim((string)$p['text']), 0, 800);
            $source = (string)$p['source'];
            $ts     = (string)$p['timestamp'];
            if (strlen($text) < 5) continue;
            $nlp   = nlp_analyze($text);
            $label = (string)$nlp['sentiment'];
            $pol   = (float)$nlp['polarity'];
            $subj  = (float)$nlp['subjectivity'];
            $emo   = (string)$nlp['emotion'];
            $tox   = (float)$nlp['toxicity'];
            if ($label==='Positive') $pos++;
            elseif ($label==='Negative') $neg++;
            else $neu++;
            $totalPol += $pol;
            if (isset($emotions[$emo])) $emotions[$emo]++;
            if (!in_array($source, $sourcesUsed)) $sourcesUsed[] = $source;
            $results[] = array('text'=>$text,'sentiment'=>$label,'polarity'=>$pol,
                'subjectivity'=>$subj,'emotion'=>$emo,'toxicity'=>$tox,
                'sarcastic'=>false,'source'=>$source,'timestamp'=>$ts,
                'engine'=>'php_lexicon','scores'=>array());
        } catch (Exception $e) { continue; }
    }
}

$n      = count($results);
$avgPol = $n > 0 ? round($totalPol/$n, 4) : 0.0;
$srcStr = implode(', ', $sourcesUsed);

arsort($keyphraseFreq);
$topPhrases = array_keys(array_slice($keyphraseFreq, 0, 10));

// Human-readable engine name
$engineLabel = 'PHP Lexicon';
if (strpos($engineUsed, 'roberta') !== false || strpos($engineUsed, 'local') !== false) {
    $engineLabel = 'RoBERTa + VADER + TextBlob (92% accuracy)';
} elseif (strpos($engineUsed, 'huggingface') !== false || strpos($engineUsed, 'api') !== false) {
    $engineLabel = 'HuggingFace API + VADER + TextBlob (85% accuracy)';
} elseif (strpos($engineUsed, 'vader') !== false || strpos($engineUsed, 'python') !== false) {
    $engineLabel = 'VADER + TextBlob (78% accuracy)';
}

// Save session
try {
    $kwe = $db->real_escape_string($keyword);
    $sre = $db->real_escape_string($srcStr);
    $ene = $db->real_escape_string($engineLabel);
    $db->query("INSERT INTO sessions (keyword,total_posts,positive,negative,neutral,avg_polarity,sources_used,nlp_engine) VALUES ('{$kwe}',{$n},{$pos},{$neg},{$neu},{$avgPol},'{$sre}','{$ene}')");
} catch (Exception $e) {}

$response = array(
    'keyword'      => $keyword,
    'total'        => $n,
    'source'       => $srcStr ? $srcStr : 'Sample Dataset',
    'is_real_data' => count($sourcesUsed) > 0,
    'from_cache'   => false,
    'nlp_engine'   => $engineLabel,
    'summary'      => array('positive'=>$pos,'negative'=>$neg,'neutral'=>$neu,'avg_polarity'=>$avgPol),
    'emotions'     => $emotions,
    'top_phrases'  => $topPhrases,
    'results'      => $results
);

try { setCache($cacheKey, $response, 3600); } catch (Exception $e) {}
echo json_encode($response);
