<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once '../includes/db.php';
$db    = getDB();
$total = $db->query('SELECT COUNT(*) FROM posts')->fetch_row()[0];
$pos   = $db->query("SELECT COUNT(*) FROM posts WHERE sentiment='Positive'")->fetch_row()[0];
$neg   = $db->query("SELECT COUNT(*) FROM posts WHERE sentiment='Negative'")->fetch_row()[0];
$neu   = $db->query("SELECT COUNT(*) FROM posts WHERE sentiment='Neutral'")->fetch_row()[0];
$avgP  = $db->query('SELECT AVG(polarity) FROM posts')->fetch_row()[0];
$kws   = $db->query('SELECT keyword,COUNT(*) n FROM posts GROUP BY keyword ORDER BY n DESC LIMIT 10')->fetch_all(MYSQLI_ASSOC);
echo json_encode(array('total_analysed'=>(int)$total,'positive'=>(int)$pos,'negative'=>(int)$neg,'neutral'=>(int)$neu,'avg_polarity'=>round((float)$avgP,4),'top_keywords'=>$kws));
