<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once '../includes/db.php';
$db = getDB();
$rows = $db->query("SELECT keyword, COUNT(*) n, AVG(polarity) avg_pol, MAX(created_at) last_seen FROM posts WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR) GROUP BY keyword ORDER BY n DESC, last_seen DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);
echo json_encode($rows);
