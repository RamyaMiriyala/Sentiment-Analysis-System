@echo off
title SentiScope NLP Server
color 0A
echo.
echo  =====================================================
echo    SentiScope Real NLP Server
echo    VADER + TextBlob + RoBERTa Transformers
echo  =====================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python not found!
    echo  Download from: https://python.org
    pause
    exit
)

echo  Installing NLP libraries (first time only)...
echo.
pip install nltk textblob vaderSentiment transformers torch requests -q
echo.
echo  Starting NLP server...
echo  Keep this window OPEN while using SentiScope!
echo.
python nlp_server.py
pause
