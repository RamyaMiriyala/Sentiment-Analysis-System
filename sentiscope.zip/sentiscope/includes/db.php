<?php
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'sentiscope';

function getDB() {
    global $DB_HOST, $DB_USER, $DB_PASS, $DB_NAME;
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
        if ($conn->connect_error) die(json_encode(array('error' => 'DB: ' . $conn->connect_error)));
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

function rateLimit($ip, $max = 15, $window = 60) {
    try {
        $db  = getDB();
        $key = 'rl_' . md5($ip) . '_' . floor(time() / $window);
        $exp = date('Y-m-d H:i:s', time() + $window);
        $stmt = $db->prepare('SELECT data FROM cache WHERE cache_key=? AND expires_at > NOW()');
        $stmt->bind_param('s', $key); $stmt->execute();
        $row   = $stmt->get_result()->fetch_assoc(); $stmt->close();
        $count = $row ? (int)$row['data'] + 1 : 1;
        if ($count > $max) return false;
        $cs = (string)$count;
        $s2 = $db->prepare('INSERT INTO cache (cache_key,data,expires_at) VALUES (?,?,?) ON DUPLICATE KEY UPDATE data=?,expires_at=?');
        $s2->bind_param('sssss', $key, $cs, $exp, $cs, $exp); $s2->execute(); $s2->close();
        return true;
    } catch (Exception $e) { return true; }
}

function getCache($key) {
    try {
        $db   = getDB();
        $stmt = $db->prepare('SELECT data FROM cache WHERE cache_key=? AND expires_at > NOW()');
        $stmt->bind_param('s', $key); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        return $row ? json_decode($row['data'], true) : null;
    } catch (Exception $e) { return null; }
}

function setCache($key, $data, $ttl = 3600) {
    try {
        $db   = getDB();
        $exp  = date('Y-m-d H:i:s', time() + $ttl);
        $d    = json_encode($data);
        $stmt = $db->prepare('INSERT INTO cache (cache_key,data,expires_at) VALUES (?,?,?) ON DUPLICATE KEY UPDATE data=?,expires_at=?');
        $stmt->bind_param('sssss', $key, $d, $exp, $d, $exp); $stmt->execute(); $stmt->close();
    } catch (Exception $e) {}
}
