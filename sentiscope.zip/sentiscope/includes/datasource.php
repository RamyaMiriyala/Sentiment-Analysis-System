<?php
/**
 * datasource.php - Multi-source data fetcher
 * STRICT relevance filtering - ALL keyword words must appear in EVERY post
 * LATEST posts only - sorted by date, max 7 days old
 */

define('MAX_POST_AGE_DAYS', 7);   // Only fetch posts from last 7 days
define('MIN_POST_LENGTH',   20);  // Minimum characters per post
define('MIN_WORD_COUNT',     5);  // Minimum words per post

function httpGet($url, $extraHeaders = array(), $timeout = 6) {
    try {
        $headers = array_merge(array(
            'User-Agent: Mozilla/5.0 (compatible; SentiScope/3.0; educational)',
            'Accept: application/json, text/xml, */*'
        ), $extraHeaders);
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL            => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => $timeout,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER     => $headers,
                CURLOPT_ENCODING       => ''
            ));
            $body = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_error($ch);
            curl_close($ch);
            if ($err || $code < 200 || $code >= 300 || !$body) return false;
            return $body;
        }
        $ctx = stream_context_create(array('http' => array(
            'timeout' => $timeout, 'ignore_errors' => true,
            'header'  => implode("\r\n", $headers)
        )));
        $body = @file_get_contents($url, false, $ctx);
        return $body !== false ? $body : false;
    } catch (Exception $e) { return false; }
}

function cleanStr($t) {
    try {
        $t = strip_tags($t);
        $t = html_entity_decode($t, ENT_QUOTES, 'UTF-8');
        $t = preg_replace('/https?:\/\/\S+/', '', $t);
        $t = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $t);
        $t = preg_replace('/[^\x20-\x7E\s]/', '', $t);
        $t = preg_replace('/\s+/', ' ', $t);
        return trim(substr($t, 0, 600));
    } catch (Exception $e) { return ''; }
}

function splitSentences($text) {
    try {
        $text  = preg_replace('/\s+/', ' ', strip_tags($text));
        $parts = preg_split('/(?<=[.!?])\s+(?=[A-Z])/', $text);
        return array_values(array_filter(array_map('trim', $parts), function($s) {
            return strlen($s) > MIN_POST_LENGTH;
        }));
    } catch (Exception $e) { return array(); }
}

function safeJsonDecode($data) {
    if (empty($data)) return null;
    $data = preg_replace('/^\xEF\xBB\xBF/', '', $data);
    $json = json_decode($data, true);
    return json_last_error() === JSON_ERROR_NONE ? $json : null;
}

// ── Strict relevance check ────────────────────────────────
function isRelevant($text, $keyword) {
    if (empty($keyword)) return true;

    $textLower    = strtolower(trim($text));
    $keywordLower = strtolower(trim($keyword));

    // Must contain exact phrase
    if (strpos($textLower, $keywordLower) !== false) return true;

    // For multi-word: EVERY word must appear
    $words = array_values(array_filter(
        explode(' ', $keywordLower),
        function($w) { return strlen($w) > 1; }
    ));

    if (empty($words)) return false;

    // Single word - strict exact match only
    if (count($words) === 1) {
        // Must appear as a whole word, not part of another word
        return preg_match('/\b' . preg_quote($words[0], '/') . '\b/', $textLower) === 1;
    }

    // Multi-word - ALL words must be present as whole words
    foreach ($words as $word) {
        if (strlen($word) <= 1) continue;
        if (!preg_match('/\b' . preg_quote($word, '/') . '\b/', $textLower)) {
            return false;
        }
    }
    return true;
}

// ── Check if post is recent enough ───────────────────────
function isRecent($timestamp) {
    if (empty($timestamp)) return true; // no timestamp = include
    try {
        $ts      = strtotime($timestamp);
        $cutoff  = time() - (MAX_POST_AGE_DAYS * 86400);
        return $ts >= $cutoff;
    } catch (Exception $e) { return true; }
}

// ── Make post with strict filters ────────────────────────
function makePost($text, $source, $keyword, $ts = null) {
    try {
        $text = cleanStr($text);

        // Length filter
        if (strlen($text) < MIN_POST_LENGTH) return null;

        // Word count filter
        if (str_word_count($text) < MIN_WORD_COUNT) return null;

        // Relevance filter - STRICT
        if (!isRelevant($text, $keyword)) return null;

        // Recency filter
        if ($ts && !isRecent($ts)) return null;

        return array(
            'text'      => $text,
            'source'    => $source,
            'timestamp' => $ts ? $ts : date('Y-m-d H:i:s')
        );
    } catch (Exception $e) { return null; }
}

// ── Sort posts by date descending ─────────────────────────
function sortByDate($posts) {
    usort($posts, function($a, $b) {
        $ta = isset($a['timestamp']) ? strtotime($a['timestamp']) : 0;
        $tb = isset($b['timestamp']) ? strtotime($b['timestamp']) : 0;
        return $tb - $ta; // newest first
    });
    return $posts;
}

/* ── Reddit ──────────────────────────────────────────────── */
function fetchReddit($keyword, $limit = 40) {
    $posts = array();
    try {
        $enc  = urlencode($keyword);
        // Use exact phrase search with quotes for stricter results
        $encPhrase = urlencode('"' . $keyword . '"');
        $urls = array(
            "https://www.reddit.com/search.json?q={$encPhrase}&sort=new&limit=50&t=week",
            "https://www.reddit.com/search.json?q={$enc}&sort=new&limit=50&t=week",
            "https://www.reddit.com/search.json?q={$enc}&sort=new&limit=50&t=month"
        );
        foreach ($urls as $url) {
            try {
                $data = httpGet($url);
                if (!$data) continue;
                $json = safeJsonDecode($data);
                if (!$json || !isset($json['data']['children'])) continue;
                foreach ($json['data']['children'] as $child) {
                    try {
                        $d  = isset($child['data']) ? $child['data'] : array();
                        $ts = isset($d['created_utc']) ? date('Y-m-d H:i:s', (int)$d['created_utc']) : date('Y-m-d H:i:s');

                        // Skip old posts
                        if (!isRecent($ts)) continue;

                        if (!empty($d['title'])) {
                            $p = makePost($d['title'], 'Reddit', $keyword, $ts);
                            if ($p) $posts[] = $p;
                        }
                        if (!empty($d['selftext']) && !in_array($d['selftext'], array('[removed]','[deleted]'))) {
                            // Check the full selftext for relevance first
                            if (isRelevant($d['selftext'], $keyword)) {
                                foreach (array_slice(splitSentences($d['selftext']), 0, 3) as $s) {
                                    $p = makePost($s, 'Reddit', $keyword, $ts);
                                    if ($p) $posts[] = $p;
                                }
                            }
                        }
                        if (count($posts) >= $limit) break 2;
                    } catch (Exception $e) { continue; }
                }
                if (count($posts) >= $limit) break;
            } catch (Exception $e) { continue; }
        }
    } catch (Exception $e) {}
    return sortByDate($posts);
}

/* ── Hacker News ─────────────────────────────────────────── */
function fetchHackerNews($keyword, $limit = 20) {
    $posts = array();
    try {
        $enc  = urlencode($keyword);
        // numericFilters to get recent posts
        $data = httpGet("https://hn.algolia.com/api/v1/search_by_date?query={$enc}&tags=story&hitsPerPage={$limit}&numericFilters=created_at_i>" . (time() - MAX_POST_AGE_DAYS * 86400));
        if (!$data) {
            // Fallback without date filter
            $data = httpGet("https://hn.algolia.com/api/v1/search?query={$enc}&tags=story&hitsPerPage={$limit}");
        }
        if (!$data) return $posts;
        $json = safeJsonDecode($data);
        if (!$json || !isset($json['hits'])) return $posts;
        foreach ($json['hits'] as $hit) {
            try {
                $ts = !empty($hit['created_at']) ? date('Y-m-d H:i:s', strtotime($hit['created_at'])) : date('Y-m-d H:i:s');
                if (!empty($hit['title'])) {
                    $p = makePost($hit['title'], 'HackerNews', $keyword, $ts);
                    if ($p) $posts[] = $p;
                }
                if (!empty($hit['story_text']) && isRelevant($hit['story_text'], $keyword)) {
                    foreach (array_slice(splitSentences($hit['story_text']), 0, 2) as $s) {
                        $p = makePost($s, 'HackerNews', $keyword, $ts);
                        if ($p) $posts[] = $p;
                    }
                }
            } catch (Exception $e) { continue; }
        }
    } catch (Exception $e) {}
    return sortByDate($posts);
}

/* ── Wikipedia ───────────────────────────────────────────── */
function fetchWikipedia($keyword) {
    $posts = array();
    try {
        $enc  = urlencode(str_replace(' ', '_', $keyword));
        $data = httpGet("https://en.wikipedia.org/api/rest_v1/page/summary/{$enc}");
        if ($data) {
            $json = safeJsonDecode($data);
            if ($json && !empty($json['extract'])) {
                // Only use Wikipedia if the title closely matches the keyword
                $title = isset($json['title']) ? strtolower($json['title']) : '';
                $kwLow = strtolower($keyword);
                if (similar_text($title, $kwLow) / max(strlen($title), strlen($kwLow)) > 0.5) {
                    foreach (array_slice(splitSentences($json['extract']), 0, 4) as $s) {
                        $p = makePost($s, 'Wikipedia', $keyword);
                        if ($p) $posts[] = $p;
                    }
                }
            }
        }
    } catch (Exception $e) {}
    return $posts;
}

/* ── Mastodon ────────────────────────────────────────────── */
function fetchMastodon($keyword, $limit = 20) {
    $posts = array();
    try {
        $enc  = urlencode($keyword);
        $data = httpGet("https://mastodon.social/api/v2/search?q={$enc}&type=statuses&limit={$limit}&resolve=false");
        if (!$data) return $posts;
        $json = safeJsonDecode($data);
        if (!$json || !isset($json['statuses'])) return $posts;
        foreach ($json['statuses'] as $status) {
            try {
                if (empty($status['content'])) continue;
                $text = strip_tags($status['content']);
                $ts   = !empty($status['created_at']) ? date('Y-m-d H:i:s', strtotime($status['created_at'])) : date('Y-m-d H:i:s');
                if (!isRecent($ts)) continue;
                $p = makePost($text, 'Mastodon', $keyword, $ts);
                if ($p) $posts[] = $p;
            } catch (Exception $e) { continue; }
        }
    } catch (Exception $e) {}
    return sortByDate($posts);
}

/* ── Bluesky ─────────────────────────────────────────────── */
function fetchBluesky($keyword, $limit = 20) {
    $posts = array();
    try {
        $enc  = urlencode($keyword);
        $data = httpGet("https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?q={$enc}&limit={$limit}&sort=latest");
        if (!$data) return $posts;
        $json = safeJsonDecode($data);
        if (!$json || !isset($json['posts'])) return $posts;
        foreach ($json['posts'] as $post) {
            try {
                $text = isset($post['record']['text']) ? $post['record']['text'] : '';
                if (empty($text)) continue;
                $ts = !empty($post['record']['createdAt']) ? date('Y-m-d H:i:s', strtotime($post['record']['createdAt'])) : date('Y-m-d H:i:s');
                if (!isRecent($ts)) continue;
                $p = makePost($text, 'Bluesky', $keyword, $ts);
                if ($p) $posts[] = $p;
            } catch (Exception $e) { continue; }
        }
    } catch (Exception $e) {}
    return sortByDate($posts);
}

/* ── RSS Feeds ───────────────────────────────────────────── */
function fetchRSS($keyword, $limit = 25) {
    $posts   = array();
    $kwLower = strtolower($keyword);
    $feeds   = array(
        'BBC News'     => 'http://feeds.bbci.co.uk/news/rss.xml',
        'BBC Tech'     => 'http://feeds.bbci.co.uk/news/technology/rss.xml',
        'Reuters'      => 'https://feeds.reuters.com/reuters/topNews',
        'Guardian'     => 'https://www.theguardian.com/world/rss',
        'TechCrunch'   => 'https://techcrunch.com/feed/',
        'Ars Technica' => 'http://feeds.arstechnica.com/arstechnica/index',
        'CNN'          => 'http://rss.cnn.com/rss/edition.rss',
        'NPR'          => 'https://feeds.npr.org/1001/rss.xml',
        'Al Jazeera'   => 'https://www.aljazeera.com/xml/rss/all.xml',
        'Wired'        => 'https://www.wired.com/feed/rss'
    );
    foreach ($feeds as $name => $feedUrl) {
        try {
            $data = httpGet($feedUrl);
            if (empty($data)) continue;
            $data = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $data);
            $data = preg_replace('/[^\x09\x0A\x0D\x20-\x{D7FF}\x{E000}-\x{FFFD}]+/u', ' ', $data);
            $prevXmlErrors = libxml_use_internal_errors(true);
            $xml = @simplexml_load_string($data);
            libxml_clear_errors();
            libxml_use_internal_errors($prevXmlErrors);
            if (!$xml || !is_object($xml)) continue;

            $items = array();
            if (isset($xml->channel->item)) foreach ($xml->channel->item as $i) $items[] = $i;
            if (isset($xml->entry))          foreach ($xml->entry as $i)         $items[] = $i;

            foreach ($items as $item) {
                try {
                    $title = isset($item->title)       ? (string)$item->title       : '';
                    $desc  = isset($item->description) ? (string)$item->description : '';
                    if (!$desc && isset($item->summary)) $desc = (string)$item->summary;

                    // Title must contain all keyword words
                    if (!isRelevant($title . ' ' . $desc, $keyword)) continue;

                    $ts = isset($item->pubDate) ? date('Y-m-d H:i:s', strtotime((string)$item->pubDate)) : date('Y-m-d H:i:s');

                    // Skip old RSS items
                    if (!isRecent($ts)) continue;

                    if ($title) {
                        $p = makePost($title, $name, $keyword, $ts);
                        if ($p) $posts[] = $p;
                    }
                    foreach (array_slice(splitSentences($desc), 0, 2) as $s) {
                        $p = makePost($s, $name, $keyword, $ts);
                        if ($p) $posts[] = $p;
                    }
                    if (count($posts) >= $limit) break 2;
                } catch (Exception $e) { continue; }
            }
        } catch (Exception $e) { continue; }
    }
    return sortByDate($posts);
}

/* ── Steam Reviews ───────────────────────────────────────── */
function fetchSteam($keyword, $limit = 15) {
    $posts = array();
    try {
        $enc   = urlencode($keyword);
        $data  = httpGet("https://store.steampowered.com/api/storesearch/?term={$enc}&l=english&cc=US");
        if (!$data) return $posts;
        $json  = safeJsonDecode($data);
        if (!$json || empty($json['items'])) return $posts;
        $appId = $json['items'][0]['id'];
        $rdata = httpGet("https://store.steampowered.com/appreviews/{$appId}?json=1&filter=recent&language=english&num_per_page={$limit}");
        if (!$rdata) return $posts;
        $rjson = safeJsonDecode($rdata);
        if (!$rjson || empty($rjson['reviews'])) return $posts;
        foreach ($rjson['reviews'] as $review) {
            try {
                if (empty($review['review'])) continue;
                $ts = !empty($review['timestamp_created']) ? date('Y-m-d H:i:s', $review['timestamp_created']) : date('Y-m-d H:i:s');
                foreach (array_slice(splitSentences($review['review']), 0, 2) as $s) {
                    $p = makePost($s, 'Steam', '', $ts); // Steam reviews are already relevant
                    if ($p) $posts[] = $p;
                }
            } catch (Exception $e) { continue; }
        }
    } catch (Exception $e) {}
    return sortByDate($posts);
}

/* ── GitHub ──────────────────────────────────────────────── */
function fetchGitHub($keyword, $limit = 15) {
    $posts = array();
    try {
        $enc  = urlencode($keyword);
        $data = httpGet(
            "https://api.github.com/search/issues?q={$enc}&sort=created&order=desc&per_page={$limit}",
            array('Accept: application/vnd.github.v3+json')
        );
        if (!$data) return $posts;
        $json = safeJsonDecode($data);
        if (!$json || empty($json['items'])) return $posts;
        foreach ($json['items'] as $issue) {
            try {
                $ts = !empty($issue['created_at']) ? date('Y-m-d H:i:s', strtotime($issue['created_at'])) : date('Y-m-d H:i:s');
                if (!isRecent($ts)) continue;
                if (!empty($issue['title'])) {
                    $p = makePost($issue['title'], 'GitHub', $keyword, $ts);
                    if ($p) $posts[] = $p;
                }
                if (!empty($issue['body']) && isRelevant($issue['body'], $keyword)) {
                    foreach (array_slice(splitSentences($issue['body']), 0, 2) as $s) {
                        $p = makePost($s, 'GitHub', $keyword, $ts);
                        if ($p) $posts[] = $p;
                    }
                }
            } catch (Exception $e) { continue; }
        }
    } catch (Exception $e) {}
    return sortByDate($posts);
}

/* ── Sample Fallback ─────────────────────────────────────── */
function generateSampleData($keyword, $count = 50) {
    $templates = array(
        array('People are saying {kw} is absolutely amazing and they cannot stop talking about it.', 'pos'),
        array('Just experienced {kw} for the first time and it totally exceeded all expectations.', 'pos'),
        array('{kw} is genuinely impressive. The quality and results speak for themselves completely.', 'pos'),
        array('The latest updates to {kw} look incredibly promising with so much innovation happening.', 'pos'),
        array('{kw} just keeps getting better every single day. Highly recommend checking it out.', 'pos'),
        array('So grateful for {kw}. It has made everything so much easier and more enjoyable overall.', 'pos'),
        array('{kw} delivered beyond all expectations this time. Absolutely phenomenal work by everyone.', 'pos'),
        array('Cannot believe how far {kw} has come recently. This is truly groundbreaking stuff.', 'pos'),
        array('{kw} continues to set the gold standard in its field. Absolutely world class quality.', 'pos'),
        array('Every day more and more people are impressed by {kw}. The results are outstanding.', 'pos'),
        array('Really disappointed with {kw} lately. Expected so much more from them honestly.', 'neg'),
        array('{kw} is becoming a total disaster. Nobody seems to know what direction they are heading.', 'neg'),
        array('Why is {kw} still having so many problems after all this time. Incredibly frustrating.', 'neg'),
        array('I have completely lost faith in {kw}. This level of quality is totally unacceptable.', 'neg'),
        array('The hype around {kw} is completely ridiculous. It is massively overrated by everyone.', 'neg'),
        array('Wasted so much time dealing with {kw} problems. This is absolutely never happening again.', 'neg'),
        array('{kw} promised so much but delivered nothing at all. What a massive and disappointing let down.', 'neg'),
        array('The overall quality of {kw} has taken a serious nosedive recently. Very concerning trend.', 'neg'),
        array('Save yourself the trouble and avoid {kw}. It is simply not worth your time or money.', 'neg'),
        array('Another complete disaster from {kw}. When will this ongoing nightmare finally end.', 'neg'),
        array('Seeing a lot of discussion about {kw} today. Very interesting to watch how things unfold.', 'neu'),
        array('{kw} is trending across social media right now. Opinions seem very divided overall.', 'neu'),
        array('Read a detailed analysis of {kw} today. There are valid points on both sides of the debate.', 'neu'),
        array('The latest data on {kw} presents a mixed picture. Neither clearly positive nor clearly negative.', 'neu'),
        array('{kw} continues to evolve rapidly. Time will tell whether this is really the right direction.', 'neu'),
        array('Checking out all the latest developments in {kw} this week. More research is definitely needed.', 'neu'),
        array('There are many different perspectives on {kw} and all of them seem worth considering carefully.', 'neu'),
        array('A new comprehensive report came out about {kw} today. The findings are somewhat mixed.', 'neu'),
        array('Watching the entire {kw} situation very carefully. No strong opinion has been formed yet.', 'neu'),
        array('{kw} clearly has both significant advantages and disadvantages depending on your specific use case.', 'neu'),
    );
    $sources = array('Reddit','HackerNews','Mastodon','Bluesky','RSS News','GitHub');
    srand(crc32(strtolower($keyword)));
    $pos = array_values(array_filter($templates, function($t){return $t[1]==='pos';}));
    $neg = array_values(array_filter($templates, function($t){return $t[1]==='neg';}));
    $neu = array_values(array_filter($templates, function($t){return $t[1]==='neu';}));
    $pN=(int)($count*0.40);$nN=(int)($count*0.33);$uN=$count-$pN-$nN;
    $posts=array();
    $add=function($pool,$n) use ($keyword,$sources,&$posts){
        for($i=0;$i<$n;$i++){
            $t=$pool[$i%count($pool)];
            $posts[]=array(
                'text'      => str_replace('{kw}',$keyword,$t[0]),
                'source'    => $sources[array_rand($sources)],
                'timestamp' => date('Y-m-d H:i:s', time()-rand(60,86400)) // sample posts within last 24h
            );
        }
    };
    $add($pos,$pN);$add($neg,$nN);$add($neu,$uN);
    shuffle($posts);
    return array_slice($posts,0,$count);
}

/* ── Main Orchestrator ───────────────────────────────────── */
function fetchRealData($keyword, $count = 50, $selectedSources = array()) {
    $all    = array();
    $per    = max(20, (int)($count / 3));
    $useAll = empty($selectedSources);

    if ($useAll || in_array('reddit',     $selectedSources)) { try { $all = array_merge($all, fetchReddit($keyword, $per));         } catch (Exception $e) {} }
    if ($useAll || in_array('hackernews', $selectedSources)) { try { $all = array_merge($all, fetchHackerNews($keyword, $per));     } catch (Exception $e) {} }
    if ($useAll || in_array('mastodon',   $selectedSources)) { try { $all = array_merge($all, fetchMastodon($keyword, $per));       } catch (Exception $e) {} }
    if ($useAll || in_array('bluesky',    $selectedSources)) { try { $all = array_merge($all, fetchBluesky($keyword, $per));        } catch (Exception $e) {} }
    if ($useAll || in_array('rss',        $selectedSources)) { try { $all = array_merge($all, fetchRSS($keyword, $per));            } catch (Exception $e) {} }
    if ($useAll || in_array('steam',      $selectedSources)) { try { $all = array_merge($all, fetchSteam($keyword, (int)($per/2))); } catch (Exception $e) {} }
    if ($useAll || in_array('github',     $selectedSources)) { try { $all = array_merge($all, fetchGitHub($keyword, (int)($per/2)));} catch (Exception $e) {} }
    if ($useAll || in_array('wikipedia',  $selectedSources)) { try { $all = array_merge($all, fetchWikipedia($keyword));            } catch (Exception $e) {} }

    // Deduplicate
    $seen = array(); $clean = array();
    foreach ($all as $p) {
        try {
            if (empty($p['text']) || strlen($p['text']) < MIN_POST_LENGTH) continue;
            $key = md5(strtolower(substr($p['text'], 0, 80)));
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $clean[]    = $p;
        } catch (Exception $e) { continue; }
    }

    // Sort all results by date - newest first
    $clean = sortByDate($clean);

    if (count($clean) >= 5) {
        return array_slice($clean, 0, $count);
    }

    // Fallback to sample data
    return generateSampleData($keyword, $count);
}