(function () {
  'use strict';
  var API = 'api', PG = 10;
  var S = {
    keyword: '', allPosts: [], filtered: [], page: 1,
    filter: 'All', efilter: 'All', wfilter: 'all',
    charts: {}, autoRefreshTimer: null,
    lastSummary: null, lastEmotions: null
  };

  function g(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function call(ep, method, body) {
    return fetch(API + '/' + ep, {
      method: method || 'GET',
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      return r.text().then(function (raw) {
        var j;
        try { j = JSON.parse(raw); }
        catch (e) { throw new Error('Server error: ' + raw.replace(/<[^>]+>/g, '').substring(0, 300)); }
        if (!r.ok) throw new Error(j.error || r.statusText);
        return j;
      });
    });
  }
  function post(ep, b) { return call(ep, 'POST', b); }
  function get(ep)      { return call(ep, 'GET'); }

  /* ── Navigation ──────────────────────────────────────── */
  var TITLES = {
    dashboard: 'Dashboard', posts: 'Analyzed Posts',
    charts: 'Advanced Charts', compare: 'Keyword Comparison',
    wordcloud: 'Word Cloud', history: 'History'
  };

  document.querySelectorAll('.nav-link').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      switchPanel(a.getAttribute('data-panel'));
      if (window.innerWidth <= 680) g('sidebar').classList.remove('open');
    });
  });

  g('menuBtn').addEventListener('click', function () {
    g('sidebar').classList.toggle('open');
  });

  function switchPanel(name) {
    document.querySelectorAll('.nav-link').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-panel') === name);
    });
    document.querySelectorAll('.panel').forEach(function (p) {
      p.classList.toggle('active', p.id === 'panel-' + name);
    });
    g('pageTitle').textContent = TITLES[name] || name;
    if (name === 'history')   loadHistory();
    if (name === 'wordcloud') renderWordCloud(S.wfilter);
    if (name === 'charts')    renderAdvancedCharts();
  }

  /* ── Theme toggle ────────────────────────────────────── */
  var isDark = true;
  g('themeToggle').addEventListener('click', function () {
    isDark = !isDark;
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
    g('themeToggle').textContent = isDark ? '🌙 Dark Mode' : '☀️ Light Mode';
    Object.values(S.charts).forEach(function (ch) { if (ch) ch.destroy(); });
    S.charts = {};
    if (S.lastSummary)  renderPieBar(S.lastSummary);
    if (S.lastEmotions) renderEmotionChart(S.lastEmotions);
    if (S.lastSummary)  renderGauge(S.lastSummary);
  });

  /* ── Auto-refresh ────────────────────────────────────── */
  g('autoRefresh').addEventListener('change', function () {
    if (this.checked) {
      S.autoRefreshTimer = setInterval(function () {
        if (S.keyword) doAnalyze(true);
      }, 60000);
    } else {
      clearInterval(S.autoRefreshTimer);
    }
  });

  /* ── Source checkboxes ───────────────────────────────── */
  document.querySelectorAll('.src-check').forEach(function (lbl) {
    lbl.classList.add('active');
    lbl.addEventListener('click', function () {
      var cb = lbl.querySelector('input');
      cb.checked = !cb.checked;
      lbl.classList.toggle('active', cb.checked);
    });
  });

  function getSources() {
    var s = [];
    document.querySelectorAll('.src-check input:checked').forEach(function (cb) {
      s.push(cb.value);
    });
    return s;
  }

  /* ── Chips ───────────────────────────────────────────── */
  document.querySelectorAll('.chip').forEach(function (c) {
    c.addEventListener('click', function () {
      g('kwInput').value = c.getAttribute('data-kw');
      g('kwInput').focus();
    });
  });

  /* ── Pin button ──────────────────────────────────────── */
  g('pinBtn').addEventListener('click', function () {
    var kw = g('kwInput').value.trim();
    if (!kw) return;
    post('pinned.php', { keyword: kw })
      .then(function () { loadPinned(); showAlert('📌 Pinned: ' + kw, 'success'); })
      .catch(function () {});
  });

  /* ── Clear Dashboard button ──────────────────────────── */
  g('clearDashBtn').addEventListener('click', function () {
    // Reset state
    S.keyword      = '';
    S.allPosts     = [];
    S.filtered     = [];
    S.page         = 1;
    S.filter       = 'All';
    S.efilter      = 'All';
    S.lastSummary  = null;
    S.lastEmotions = null;

    // Clear input
    g('kwInput').value = '';

    // Hide cards
    g('previewCard').style.display = 'none';
    g('sourceBadge').style.display = 'none';
    g('phrasesCard').style.display = 'none';
    g('cacheBadge').className      = 'cache-badge';

    // Reset stat values
    ['svTotal', 'svPos', 'svNeg', 'svNeu', 'svPol'].forEach(function (id) {
      g(id).textContent = '—';
    });
    g('svPol').className = 'stat-val';

    // Clear gauge
    var canvas = g('gaugeChart');
    if (canvas) {
      var ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    if (g('gaugeLabel')) g('gaugeLabel').textContent = '—';

    // Destroy all charts
    destroyCharts();

    // Reset alert and topbar
    g('alertBox').className      = 'alert-box';
    g('lastUpdated').textContent = 'No analysis yet';

    // Reset posts panel
    g('postsBox').innerHTML = '<div class="empty-msg">Run an analysis first to see posts here.</div>';
    g('pager').innerHTML    = '';

    // Reset filters
    resetFilters();

    showAlert('Dashboard cleared. Enter a new keyword to begin.', 'info');
  });

  /* ── Analyze button ──────────────────────────────────── */
  g('analyzeBtn').addEventListener('click', function () { doAnalyze(false); });
  g('kwInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') doAnalyze(false);
  });
  if (g('refreshCache')) {
    g('refreshCache').addEventListener('click', function () { doAnalyze(false, true); });
  }

  function doAnalyze(silent, forceRefresh) {
    var kw   = g('kwInput').value.trim();
    var cnt  = parseInt(g('cntInput').value, 10);
    var srcs = getSources();

    if (!kw)          { showAlert('Please enter a keyword or topic.', 'error'); return; }
    if (!srcs.length) { showAlert('Select at least one data source.', 'error'); return; }

    if (!silent) {
      setLoading(true);
      showAlert('Fetching from: ' + srcs.join(', ') + '...', 'info');
    }

    destroyMainCharts();
    g('previewCard').style.display = 'none';
    g('sourceBadge').style.display = 'none';
    g('cacheBadge').className      = 'cache-badge';

    post('analyze.php', { keyword: kw, count: cnt, sources: srcs })
      .then(function (data) {
        S.keyword      = kw;
        S.allPosts     = data.results || [];
        S.filtered     = S.allPosts.slice();
        S.page         = 1;
        S.filter       = 'All';
        S.efilter      = 'All';
        S.lastSummary  = data.summary;
        S.lastEmotions = data.emotions;

        updateStats(data.summary, data.total);
        renderGauge(data.summary);
        renderPieBar(data.summary);
        renderEmotionChart(data.emotions);
        renderPhrases(data.top_phrases);

        // Show ALL posts on dashboard
        renderPreview(S.allPosts);
        renderPostsList();
        resetFilters();

        g('lastUpdated').textContent   = kw + ' — ' + new Date().toLocaleTimeString();
        g('sourceBadge').style.display = 'inline-flex';
        if (data.nlp_engine) {
          g('nlpBadge').className = 'nlp-badge show';
          g('nlpEngine').textContent = data.nlp_engine;
        }
        g('sourceText').textContent    = (data.is_real_data ? '✅ Live: ' : '📦 Sample: ') + (data.source || 'Sample Dataset');

        if (data.from_cache) {
          g('cacheBadge').className = 'cache-badge show';
          if (g('cacheAge')) g('cacheAge').textContent = 'cached result';
        }

        if (!silent) showAlert('✓ Analyzed ' + data.total + ' posts from: ' + (data.source || 'Sample'), 'success');

        loadTrending();
        loadPinned();
      })
      .catch(function (err) { showAlert('Error: ' + err.message, 'error'); })
      .finally(function ()  { setLoading(false); });
  }

  /* ── Loading ─────────────────────────────────────────── */
  var _iv = null;
  function setLoading(on) {
    g('analyzeBtn').disabled = on;
    g('progWrap').classList.toggle('on', on);
    clearInterval(_iv);
    if (on) {
      var w = 0;
      _iv = setInterval(function () {
        w = Math.min(w + Math.random() * 9, 88);
        g('progBar').style.width = w + '%';
        if (!g('analyzeBtn').disabled) {
          g('progBar').style.width = '100%';
          clearInterval(_iv);
          setTimeout(function () { g('progBar').style.width = '0%'; }, 500);
        }
      }, 180);
    }
  }

  function showAlert(msg, type) {
    var el = g('alertBox');
    el.textContent = msg;
    el.className = 'alert-box show ' + type;
  }

  /* ── Stats ───────────────────────────────────────────── */
  function updateStats(s, total) {
    animNum(g('svTotal'), total);
    animNum(g('svPos'),   s.positive);
    animNum(g('svNeg'),   s.negative);
    animNum(g('svNeu'),   s.neutral);
    var pol = parseFloat(s.avg_polarity) || 0;
    g('svPol').textContent = (pol >= 0 ? '+' : '') + pol.toFixed(3);
    g('svPol').className = 'stat-val ' + (pol > 0.05 ? 'col-pos' : pol < -0.05 ? 'col-neg' : 'col-neu');
  }

  function animNum(el, target) {
    var t0 = performance.now(), dur = 650;
    (function step(now) {
      var p = Math.min((now - t0) / dur, 1);
      el.textContent = Math.round(p * target);
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }

  /* ── Gauge ───────────────────────────────────────────── */
  function renderGauge(s) {
    var canvas = g('gaugeChart');
    var ctx    = canvas.getContext('2d');
    canvas.width = 300; canvas.height = 160;
    ctx.clearRect(0, 0, 300, 160);

    var cx = 150, cy = 140, r = 110, sw = 22;

    // Background arc
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI, 0);
    ctx.strokeStyle = isDark ? '#1c2333' : '#d0d9e8';
    ctx.lineWidth = sw; ctx.lineCap = 'round'; ctx.stroke();

    // Value arc
    var pol      = parseFloat(s.avg_polarity) || 0;
    var endAngle = Math.PI + ((pol + 1) / 2 * Math.PI);
    var color    = pol > 0.05 ? '#4ade80' : pol < -0.05 ? '#f87171' : '#fbbf24';

    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI, endAngle);
    ctx.strokeStyle = color;
    ctx.lineWidth = sw; ctx.lineCap = 'round'; ctx.stroke();

    // Labels
    ctx.fillStyle = isDark ? '#657080' : '#5a6a80';
    ctx.font = '11px Instrument Sans';
    ctx.textAlign = 'left';  ctx.fillText('Negative', 14, 145);
    ctx.textAlign = 'right'; ctx.fillText('Positive', 286, 145);

    g('gaugeLabel').textContent = (pol >= 0 ? '+' : '') + pol.toFixed(3) + ' ' +
      (pol > 0.05 ? 'Positive' : pol < -0.05 ? 'Negative' : 'Neutral');
    g('gaugeLabel').style.color = color;
  }

  /* ── Chart helpers ───────────────────────────────────── */
  var C = {
    pos: '#4ade80', neg: '#f87171', neu: '#fbbf24',
    posd: 'rgba(74,222,128,.15)', negd: 'rgba(248,113,113,.15)', neud: 'rgba(251,191,36,.15)',
    grid: '#1c2333', tick: '#657080', bg: '#0d1017', tx: '#dde6f0'
  };

  function updateColors() {
    C.grid = isDark ? '#1c2333' : '#d0d9e8';
    C.tick = isDark ? '#657080' : '#5a6a80';
    C.bg   = isDark ? '#0d1017' : '#ffffff';
    C.tx   = isDark ? '#dde6f0' : '#1a2233';
  }

  function plugBase() {
    updateColors();
    return {
      legend: { labels: { color: C.tx, font: { family: "'Instrument Sans',sans-serif", size: 12 }, boxWidth: 12 } },
      tooltip: { backgroundColor: isDark ? '#131820' : '#ffffff', borderColor: C.grid, borderWidth: 1, titleColor: C.tx, bodyColor: C.tick }
    };
  }

  function destroyMainCharts() {
    ['pie', 'bar', 'emotion'].forEach(function (k) {
      if (S.charts[k]) { S.charts[k].destroy(); delete S.charts[k]; }
    });
  }

  function destroyCharts() {
    Object.values(S.charts).forEach(function (ch) { if (ch) ch.destroy(); });
    S.charts = {};
  }

  /* ── Pie + Bar ───────────────────────────────────────── */
  function renderPieBar(s) {
    var labels = ['Positive', 'Negative', 'Neutral'];
    var data   = [s.positive, s.negative, s.neutral];
    var colors = [C.pos, C.neg, C.neu];
    var dimmed = [C.posd, C.negd, C.neud];

    if (S.charts.pie) S.charts.pie.destroy();
    S.charts.pie = new Chart(g('pieChart'), {
      type: 'doughnut',
      data: { labels: labels, datasets: [{ data: data, backgroundColor: colors, borderColor: C.bg, borderWidth: 3, hoverOffset: 5 }] },
      options: {
        cutout: '60%', animation: { duration: 650 },
        plugins: Object.assign({}, plugBase(), {
          legend: { labels: { color: C.tx, font: { family: "'Instrument Sans',sans-serif", size: 12 }, boxWidth: 12 }, position: 'bottom' }
        })
      }
    });

    if (S.charts.bar) S.charts.bar.destroy();
    S.charts.bar = new Chart(g('barChart'), {
      type: 'bar',
      data: { labels: labels, datasets: [{ label: 'Posts', data: data, backgroundColor: dimmed, borderColor: colors, borderWidth: 2, borderRadius: 5, borderSkipped: false }] },
      options: {
        animation: { duration: 650 },
        scales: {
          x: { ticks: { color: C.tick }, grid: { color: C.grid } },
          y: { ticks: { color: C.tick }, grid: { color: C.grid }, beginAtZero: true }
        },
        plugins: Object.assign({}, plugBase(), { legend: { display: false } })
      }
    });
  }

  /* ── Emotion chart ───────────────────────────────────── */
  function renderEmotionChart(emotions) {
    if (!emotions) return;
    var labels = Object.keys(emotions);
    var data   = Object.values(emotions);
    var emoColors = {
      joy: 'rgba(74,222,128,.7)', anger: 'rgba(248,113,113,.7)',
      sadness: 'rgba(96,165,250,.7)', fear: 'rgba(167,139,250,.7)',
      surprise: 'rgba(251,191,36,.7)', disgust: 'rgba(244,114,182,.7)',
      neutral: 'rgba(100,116,139,.7)'
    };
    var bgColors = labels.map(function (l) { return emoColors[l] || 'rgba(100,116,139,.5)'; });

    if (S.charts.emotion) S.charts.emotion.destroy();
    S.charts.emotion = new Chart(g('emotionChart'), {
      type: 'bar',
      data: {
        labels: labels.map(function (l) { return l.charAt(0).toUpperCase() + l.slice(1); }),
        datasets: [{ label: 'Posts', data: data, backgroundColor: bgColors, borderRadius: 5, borderSkipped: false }]
      },
      options: {
        indexAxis: 'y', animation: { duration: 600 },
        scales: {
          x: { ticks: { color: C.tick }, grid: { color: C.grid }, beginAtZero: true },
          y: { ticks: { color: C.tick }, grid: { color: C.grid } }
        },
        plugins: Object.assign({}, plugBase(), { legend: { display: false } })
      }
    });
  }

  /* ── Key phrases ─────────────────────────────────────── */
  function renderPhrases(phrases) {
    if (!phrases || !phrases.length) { g('phrasesCard').style.display = 'none'; return; }
    g('phrasesCard').style.display = 'block';
    g('phrasesList').innerHTML = phrases.map(function (p) {
      return '<span class="phrase-tag">' + esc(p) + '</span>';
    }).join('');
  }

  /* ── Advanced charts ─────────────────────────────────── */
  function renderAdvancedCharts() {
    if (!S.allPosts.length) return;
    updateColors();

    // Timeline
    if (S.keyword) {
      get('timeline.php?keyword=' + encodeURIComponent(S.keyword)).then(function (rows) {
        if (!rows.length) return;
        if (S.charts.timeline) S.charts.timeline.destroy();
        S.charts.timeline = new Chart(g('timelineChart'), {
          type: 'line',
          data: {
            labels: rows.map(function (r) { return r.d; }),
            datasets: [
              { label: 'Avg Polarity', data: rows.map(function (r) { return parseFloat(r.avg_pol); }), borderColor: C.pos, backgroundColor: 'rgba(74,222,128,.1)', tension: 0.4, fill: true, pointRadius: 4 },
              { label: 'Positive',     data: rows.map(function (r) { return parseInt(r.pos); }),      borderColor: C.pos, borderDash: [5, 5], tension: 0.3, fill: false, yAxisID: 'y2' },
              { label: 'Negative',     data: rows.map(function (r) { return parseInt(r.neg); }),      borderColor: C.neg, borderDash: [5, 5], tension: 0.3, fill: false, yAxisID: 'y2' }
            ]
          },
          options: {
            animation: { duration: 600 },
            scales: {
              x:  { ticks: { color: C.tick }, grid: { color: C.grid } },
              y:  { ticks: { color: C.tick }, grid: { color: C.grid }, min: -1, max: 1, position: 'left' },
              y2: { ticks: { color: C.tick }, grid: { display: false }, position: 'right', beginAtZero: true }
            },
            plugins: plugBase()
          }
        });
      }).catch(function () {});
    }

    // Polarity histogram
    if (S.charts.polarity) S.charts.polarity.destroy();
    var buckets = Array(10).fill(0);
    var bLabels = ['-1.0', '-0.8', '-0.6', '-0.4', '-0.2', '0.0', '0.2', '0.4', '0.6', '0.8'];
    S.allPosts.forEach(function (p) {
      var pol = parseFloat(p.polarity) || 0;
      buckets[Math.min(9, Math.floor((pol + 1) / 0.2))]++;
    });
    S.charts.polarity = new Chart(g('polarityChart'), {
      type: 'bar',
      data: {
        labels: bLabels,
        datasets: [{
          label: 'Posts', data: buckets,
          backgroundColor: buckets.map(function (_, i) { return i < 5 ? C.negd : i === 5 ? C.neud : C.posd; }),
          borderColor:     buckets.map(function (_, i) { return i < 5 ? C.neg  : i === 5 ? C.neu  : C.pos;  }),
          borderWidth: 2, borderRadius: 4, borderSkipped: false
        }]
      },
      options: {
        animation: { duration: 600 },
        scales: {
          x: { ticks: { color: C.tick }, grid: { color: C.grid } },
          y: { ticks: { color: C.tick }, grid: { color: C.grid }, beginAtZero: true }
        },
        plugins: Object.assign({}, plugBase(), { legend: { display: false } })
      }
    });

    // Source stacked bar
    if (S.charts.source) S.charts.source.destroy();
    var srcMap = {};
    S.allPosts.forEach(function (p) {
      var src = p.source || 'Unknown';
      if (!srcMap[src]) srcMap[src] = { Positive: 0, Negative: 0, Neutral: 0 };
      srcMap[src][p.sentiment]++;
    });
    var srcLabels = Object.keys(srcMap);
    S.charts.source = new Chart(g('sourceChart'), {
      type: 'bar',
      data: {
        labels: srcLabels,
        datasets: [
          { label: 'Positive', data: srcLabels.map(function (s) { return srcMap[s].Positive; }), backgroundColor: C.posd, borderColor: C.pos, borderWidth: 2, borderRadius: 3 },
          { label: 'Negative', data: srcLabels.map(function (s) { return srcMap[s].Negative; }), backgroundColor: C.negd, borderColor: C.neg, borderWidth: 2, borderRadius: 3 },
          { label: 'Neutral',  data: srcLabels.map(function (s) { return srcMap[s].Neutral;  }), backgroundColor: C.neud, borderColor: C.neu, borderWidth: 2, borderRadius: 3 }
        ]
      },
      options: {
        animation: { duration: 600 },
        scales: {
          x: { ticks: { color: C.tick }, grid: { color: C.grid }, stacked: true },
          y: { ticks: { color: C.tick }, grid: { color: C.grid }, beginAtZero: true, stacked: true }
        },
        plugins: plugBase()
      }
    });

    // Scatter
    if (S.charts.scatter) S.charts.scatter.destroy();
    S.charts.scatter = new Chart(g('scatterChart'), {
      type: 'scatter',
      data: {
        datasets: [
          { label: 'Positive', data: S.allPosts.filter(function (p) { return p.sentiment === 'Positive'; }).map(function (p) { return { x: parseFloat(p.polarity) || 0, y: parseFloat(p.subjectivity) || 0 }; }), backgroundColor: 'rgba(74,222,128,.5)', pointRadius: 5 },
          { label: 'Negative', data: S.allPosts.filter(function (p) { return p.sentiment === 'Negative'; }).map(function (p) { return { x: parseFloat(p.polarity) || 0, y: parseFloat(p.subjectivity) || 0 }; }), backgroundColor: 'rgba(248,113,113,.5)', pointRadius: 5 },
          { label: 'Neutral',  data: S.allPosts.filter(function (p) { return p.sentiment === 'Neutral';  }).map(function (p) { return { x: parseFloat(p.polarity) || 0, y: parseFloat(p.subjectivity) || 0 }; }), backgroundColor: 'rgba(251,191,36,.5)',  pointRadius: 5 }
        ]
      },
      options: {
        animation: { duration: 600 },
        scales: {
          x: { title: { display: true, text: 'Polarity',     color: C.tick }, ticks: { color: C.tick }, grid: { color: C.grid }, min: -1, max: 1 },
          y: { title: { display: true, text: 'Subjectivity', color: C.tick }, ticks: { color: C.tick }, grid: { color: C.grid }, min: 0,  max: 1 }
        },
        plugins: plugBase()
      }
    });

    // Toxicity
    if (S.charts.toxicity) S.charts.toxicity.destroy();
    var toxBuckets = [0, 0, 0, 0, 0];
    S.allPosts.forEach(function (p) {
      var t = parseFloat(p.toxicity) || 0;
      toxBuckets[Math.min(4, Math.floor(t * 5))]++;
    });
    S.charts.toxicity = new Chart(g('toxicityChart'), {
      type: 'bar',
      data: {
        labels: ['Very Low', 'Low', 'Medium', 'High', 'Very High'],
        datasets: [{
          label: 'Posts', data: toxBuckets,
          backgroundColor: ['rgba(74,222,128,.6)', 'rgba(163,230,53,.6)', 'rgba(251,191,36,.6)', 'rgba(251,146,60,.6)', 'rgba(248,113,113,.6)'],
          borderRadius: 5, borderSkipped: false
        }]
      },
      options: {
        animation: { duration: 600 },
        scales: {
          x: { ticks: { color: C.tick }, grid: { color: C.grid } },
          y: { ticks: { color: C.tick }, grid: { color: C.grid }, beginAtZero: true }
        },
        plugins: Object.assign({}, plugBase(), { legend: { display: false } })
      }
    });
  }

  /* ── Post HTML ───────────────────────────────────────── */
  var EMOJIS = { joy: '😊', anger: '😡', sadness: '😢', fear: '😨', surprise: '😲', disgust: '🤢', neutral: '😐' };

  function postHTML(p) {
    var pol  = parseFloat(p.polarity) || 0;
    var bw   = Math.round(Math.abs(pol) * 100);
    var bc   = pol >= 0 ? C.pos : C.neg;
    var time = p.timestamp ? new Date(p.timestamp.replace(' ', 'T')).toLocaleString() : '';
    var subj = Math.round((parseFloat(p.subjectivity) || 0) * 100);
    var emo    = p.emotion || 'neutral';
    var eng    = p.engine || 'php_lexicon';
    var scores = p.scores || {};
    var tox  = parseFloat(p.toxicity) || 0;

    return '<div class="post-item">' +
      '<span class="badge ' + esc(p.sentiment) + '">' + esc(p.sentiment) + '</span>' +
      '<div class="post-body">' +
        '<div class="post-text">' + esc(p.text) + '</div>' +
        '<div class="post-meta">' +
          '<span>📡 ' + esc(p.source || 'sample') + '</span>' +
          (time ? '<span>🕐 ' + time + '</span>' : '') +
          '<span>Subjectivity: ' + subj + '%</span>' +
          '<span class="emotion-tag">' + (EMOJIS[emo] || '😐') + ' ' + esc(emo) + '</span>' +
          (tox > 0.3 ? '<span style="color:var(--neg)">⚠️ Toxic: ' + (tox * 100).toFixed(0) + '%</span>' : '') +
        '</div>' +
        '<div class="pol-row">' +
          '<span class="pol-lbl">Polarity ' + (pol >= 0 ? '+' : '') + pol.toFixed(3) + '</span>' +
          '<div class="pol-bg"><div class="pol-fill" style="width:' + bw + '%;background:' + bc + '"></div></div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  /* ── Render ALL posts on dashboard ───────────────────── */
  function renderPreview(posts) {
    g('previewList').innerHTML = posts.map(postHTML).join('');
    g('previewCard').style.display = 'block';
  }

  /* ── Posts panel ─────────────────────────────────────── */
  function renderPostsList() {
    var start = (S.page - 1) * PG;
    var slice = S.filtered.slice(start, start + PG);
    g('postsBox').innerHTML = slice.length
      ? slice.map(postHTML).join('')
      : '<div class="empty-msg">No posts match the current filter.</div>';
    renderPager();
  }

  function renderPager() {
    var total = Math.ceil(S.filtered.length / PG);
    var el = g('pager');
    el.innerHTML = '';
    if (total <= 1) return;
    for (var i = 1; i <= total; i++) {
      (function (pg) {
        var b = document.createElement('button');
        b.className = 'pg' + (pg === S.page ? ' active' : '');
        b.textContent = pg;
        b.addEventListener('click', function () { S.page = pg; renderPostsList(); });
        el.appendChild(b);
      })(i);
    }
  }

  /* ── Filters ─────────────────────────────────────────── */
  document.querySelectorAll('.fbtn[data-f]').forEach(function (b) {
    b.addEventListener('click', function () { setSentFilter(b.getAttribute('data-f')); applyFilters(); });
  });
  document.querySelectorAll('.fbtn[data-e]').forEach(function (b) {
    b.addEventListener('click', function () { setEmoFilter(b.getAttribute('data-e')); applyFilters(); });
  });
  document.querySelectorAll('.fbtn[data-wf]').forEach(function (b) {
    b.addEventListener('click', function () {
      document.querySelectorAll('.fbtn[data-wf]').forEach(function (x) { x.classList.remove('active'); });
      b.classList.add('active');
      S.wfilter = b.getAttribute('data-wf');
      renderWordCloud(S.wfilter);
    });
  });
  g('postSearch').addEventListener('input', applyFilters);

  function setSentFilter(f) {
    S.filter = f;
    document.querySelectorAll('.fbtn[data-f]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-f') === f);
    });
  }
  function setEmoFilter(f) {
    S.efilter = f;
    document.querySelectorAll('.fbtn[data-e]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-e') === f);
    });
  }
  function resetFilters() {
    setSentFilter('All');
    setEmoFilter('All');
    if (g('postSearch')) g('postSearch').value = '';
  }
  function applyFilters() {
    var q = g('postSearch').value.toLowerCase();
    S.filtered = S.allPosts.filter(function (p) {
      var mf = S.filter  === 'All' || p.sentiment === S.filter;
      var me = S.efilter === 'All' || (p.emotion || 'neutral') === S.efilter;
      var ms = !q || p.text.toLowerCase().indexOf(q) !== -1;
      return mf && me && ms;
    });
    S.page = 1;
    renderPostsList();
  }

  g('viewAllBtn').addEventListener('click', function () { switchPanel('posts'); });

  /* ── Word Cloud ──────────────────────────────────────── */
  function renderWordCloud(filter) {
    if (!S.allPosts.length) return;
    g('cloudSub').textContent = 'Keyword: ' + S.keyword +
      (filter && filter !== 'all' ? ' (' + filter + ' only)' : '');

    var posts = filter && filter !== 'all'
      ? S.allPosts.filter(function (p) { return p.sentiment === filter; })
      : S.allPosts;

    var freq = {};
    var skip = { the: 1, and: 1, for: 1, this: 1, that: 1, with: 1, from: 1, have: 1, are: 1, was: 1, were: 1, been: 1, will: 1, would: 1, could: 1, should: 1, they: 1, their: 1, them: 1, just: 1, also: 1, very: 1, into: 1, about: 1, over: 1, after: 1, before: 1, not: 1, but: 1, can: 1, its: 1 };

    posts.forEach(function (p) {
      (p.text || '').toLowerCase().split(/\W+/).forEach(function (w) {
        if (w.length > 2 && !skip[w]) freq[w] = (freq[w] || 0) + 1;
      });
    });

    var list = Object.keys(freq)
      .sort(function (a, b) { return freq[b] - freq[a]; })
      .slice(0, 80)
      .map(function (w) { return [w, Math.max(freq[w] * 7, 12)]; });

    if (typeof WordCloud === 'function') {
      var canvas = g('wcCanvas');
      canvas.width  = canvas.parentElement.offsetWidth - 32;
      canvas.height = 460;
      WordCloud(canvas, {
        list: list, gridSize: 10, weightFactor: 1.1,
        fontFamily: 'Epilogue,sans-serif',
        color: function () {
          return ['#00cba8', '#4ade80', '#fbbf24', '#f87171', '#60a5fa', '#a78bfa', '#f472b6'][Math.floor(Math.random() * 7)];
        },
        rotateRatio: 0.25, rotationSteps: 2, backgroundColor: 'transparent'
      });
    }
  }

  /* ── Compare ─────────────────────────────────────────── */
  g('compareBtn').addEventListener('click', function () {
    var kw1 = g('cmpKw1').value.trim();
    var kw2 = g('cmpKw2').value.trim();
    if (!kw1 || !kw2) {
      var a = g('cmpAlert');
      a.textContent = 'Please enter both keywords.';
      a.className = 'alert-box show error';
      return;
    }
    var a = g('cmpAlert');
    a.textContent = 'Comparing ' + kw1 + ' vs ' + kw2 + '...';
    a.className = 'alert-box show info';
    g('compareBtn').disabled = true;

    post('compare.php', { keyword1: kw1, keyword2: kw2, count: 30 })
      .then(function (data) {
        a.className = 'alert-box';
        g('compareResults').style.display = 'block';
        var r1 = data.keyword1, r2 = data.keyword2, winner = data.winner;
        g('winnerBanner').textContent = '🏆 Winner: ' + winner +
          (winner === 'Tie' ? '!' : ' wins with higher positive sentiment!');
        renderCompareCol('col1', r1);
        renderCompareCol('col2', r2);
        renderComparePie('cmpPieChart1', r1, 'cmpPie1');
        renderComparePie('cmpPieChart2', r2, 'cmpPie2');
        renderCompareBar(r1, r2);
      })
      .catch(function (err) {
        a.textContent = 'Error: ' + err.message;
        a.className = 'alert-box show error';
      })
      .finally(function () { g('compareBtn').disabled = false; });
  });

  function renderCompareCol(id, r) {
    var pol = parseFloat(r.avg_polarity) || 0;
    var pc  = pol > 0.05 ? 'col-pos' : pol < -0.05 ? 'col-neg' : 'col-neu';
    g(id).innerHTML =
      '<div class="compare-kw">' + esc(r.keyword) + '</div>' +
      '<div class="compare-stat"><span>Total Posts</span><span>' + r.total + '</span></div>' +
      '<div class="compare-stat"><span>Positive</span><span style="color:var(--pos)">' + r.positive + '</span></div>' +
      '<div class="compare-stat"><span>Negative</span><span style="color:var(--neg)">' + r.negative + '</span></div>' +
      '<div class="compare-stat"><span>Neutral</span><span style="color:var(--neu)">'  + r.neutral  + '</span></div>' +
      '<div class="compare-stat"><span>Avg Polarity</span><span class="' + pc + '">' + (pol >= 0 ? '+' : '') + pol.toFixed(3) + '</span></div>';
  }

  function renderComparePie(canvasId, r, key) {
    if (S.charts[key]) S.charts[key].destroy();
    S.charts[key] = new Chart(g(canvasId), {
      type: 'doughnut',
      data: {
        labels: ['Positive', 'Negative', 'Neutral'],
        datasets: [{ data: [r.positive, r.negative, r.neutral], backgroundColor: [C.pos, C.neg, C.neu], borderColor: C.bg, borderWidth: 3 }]
      },
      options: {
        cutout: '55%', animation: { duration: 500 },
        plugins: Object.assign({}, plugBase(), {
          legend: { labels: { color: C.tx, font: { family: "'Instrument Sans',sans-serif", size: 11 }, boxWidth: 10 }, position: 'bottom' },
          title:  { display: true, text: r.keyword, color: C.tx, font: { family: "'Epilogue',sans-serif", size: 13, weight: 'bold' } }
        })
      }
    });
  }

  function renderCompareBar(r1, r2) {
    if (S.charts.cmpBar) S.charts.cmpBar.destroy();
    S.charts.cmpBar = new Chart(g('cmpBarChart'), {
      type: 'bar',
      data: {
        labels: ['Positive', 'Negative', 'Neutral', 'Avg Polarity×100'],
        datasets: [
          { label: r1.keyword, data: [r1.positive, r1.negative, r1.neutral, Math.round(r1.avg_polarity * 100)], backgroundColor: C.posd, borderColor: C.pos, borderWidth: 2, borderRadius: 4 },
          { label: r2.keyword, data: [r2.positive, r2.negative, r2.neutral, Math.round(r2.avg_polarity * 100)], backgroundColor: C.negd, borderColor: C.neg, borderWidth: 2, borderRadius: 4 }
        ]
      },
      options: {
        animation: { duration: 600 },
        scales: {
          x: { ticks: { color: C.tick }, grid: { color: C.grid } },
          y: { ticks: { color: C.tick }, grid: { color: C.grid }, beginAtZero: true }
        },
        plugins: plugBase()
      }
    });
  }

  /* ── History ─────────────────────────────────────────── */
  function loadHistory() {
    get('history.php?limit=30').then(function (rows) {
      if (!rows.length) {
        g('histBody').innerHTML = '<tr><td colspan="9" class="empty-msg">No history yet.</td></tr>';
        return;
      }
      g('histBody').innerHTML = rows.map(function (s) {
        var pol = parseFloat(s.avg_polarity) || 0;
        var pc  = pol > 0.05 ? 'color:var(--pos)' : pol < -0.05 ? 'color:var(--neg)' : 'color:var(--neu)';
        var dt  = s.created_at ? new Date(s.created_at.replace(' ', 'T')).toLocaleString() : '—';
        return '<tr>' +
          '<td><span class="kw-tag">' + esc(s.keyword) + '</span></td>' +
          '<td>' + s.total_posts + '</td>' +
          '<td style="color:var(--pos)">' + s.positive + '</td>' +
          '<td style="color:var(--neg)">' + s.negative + '</td>' +
          '<td style="color:var(--neu)">' + s.neutral  + '</td>' +
          '<td style="' + pc + '">' + (pol >= 0 ? '+' : '') + pol.toFixed(3) + '</td>' +
          '<td style="color:var(--mu);font-size:.72rem">' + (s.sources_used || '—') + '</td>' +
          '<td style="color:var(--mu)">' + dt + '</td>' +
          '<td>' +
            '<button class="action-btn" onclick="rerunKw(\'' + esc(s.keyword) + '\')">▶ Re-run</button>' +
            '<button class="action-btn" onclick="exportKw(\'' + esc(s.keyword) + '\')">↓ CSV</button>' +
          '</td>' +
        '</tr>';
      }).join('');
    }).catch(function () {
      g('histBody').innerHTML = '<tr><td colspan="9" class="empty-msg">Could not load history.</td></tr>';
    });
  }

  window.rerunKw = function (kw) {
    g('kwInput').value = kw;
    switchPanel('dashboard');
    setTimeout(function () { doAnalyze(false); }, 200);
  };
  window.exportKw = function (kw) {
    window.open(API + '/export.php?keyword=' + encodeURIComponent(kw));
  };

  g('clearBtn').addEventListener('click', function () {
    if (!confirm('Clear all stored data? This cannot be undone.')) return;
    fetch(API + '/clear.php', { method: 'POST' }).then(function () { loadHistory(); });
  });

  /* ── Export ──────────────────────────────────────────── */
  g('exportCsvBtn').addEventListener('click', function () {
    if (!S.keyword) { showAlert('Run an analysis first.', 'error'); return; }
    window.open(API + '/export.php?keyword=' + encodeURIComponent(S.keyword));
  });
  g('exportPdfBtn').addEventListener('click', function () {
    if (!S.keyword) { showAlert('Run an analysis first.', 'error'); return; }
    window.open(API + '/export.php?keyword=' + encodeURIComponent(S.keyword) + '&format=pdf');
  });

  /* ── Pinned ──────────────────────────────────────────── */
  function loadPinned() {
    get('pinned.php').then(function (rows) {
      if (!rows.length) {
        g('pinnedList').innerHTML = '<div class="pinned-empty">No pinned keywords</div>';
        return;
      }
      g('pinnedList').innerHTML = rows.map(function (r) {
        return '<div class="pinned-item">' +
          '<span class="pinned-kw" onclick="rerunKw(\'' + esc(r.keyword) + '\')">' + esc(r.keyword) + '</span>' +
          '<button class="pinned-del" onclick="unpinKw(\'' + esc(r.keyword) + '\')">✕</button>' +
        '</div>';
      }).join('');
    }).catch(function () {});
  }

  window.unpinKw = function (kw) {
    fetch(API + '/pinned.php?keyword=' + encodeURIComponent(kw), { method: 'DELETE' })
      .then(function () { loadPinned(); });
  };

  /* ── Trending ────────────────────────────────────────── */
  function loadTrending() {
    get('trending.php').then(function (rows) {
      if (!rows.length) {
        g('trendingList').innerHTML = '<div class="pinned-empty">No data yet</div>';
        return;
      }
      g('trendingList').innerHTML = rows.slice(0, 6).map(function (r) {
        var pol = parseFloat(r.avg_pol) || 0;
        var cls = pol > 0.05 ? 'trend-pos' : pol < -0.05 ? 'trend-neg' : 'trend-neu';
        var lbl = pol > 0.05 ? '↑' : pol < -0.05 ? '↓' : '→';
        return '<div class="trend-item" onclick="rerunKw(\'' + esc(r.keyword) + '\')">' +
          '<span class="trend-badge ' + cls + '">' + lbl + '</span>' +
          '<span>' + esc(r.keyword) + '</span>' +
          '<span style="margin-left:auto;color:var(--mu);font-size:.7rem">' + r.n + '</span>' +
        '</div>';
      }).join('');
    }).catch(function () {});
  }

  /* ── DB Status ───────────────────────────────────────── */
  function checkDB() {
    get('stats.php')
      .then(function () { g('dbDot').className = 'dot ok'; g('dbLabel').textContent = 'DB: Connected'; })
      .catch(function () { g('dbDot').className = 'dot err'; g('dbLabel').textContent = 'DB: Offline'; });
  }

  checkDB();
  setInterval(checkDB, 30000);
  loadPinned();
  loadTrending();

})();
